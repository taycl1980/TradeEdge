import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase-server';
import { getActiveEdge } from '@/lib/edgeRepo';
import EdgeBuilderClient from './EdgeBuilderClient';

export default async function EdgeBuilderPage({ searchParams }: { searchParams: { edit?: string } }) {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const existing = await getActiveEdge(supabase, user.id);
  const isEdit = searchParams.edit === '1';

  // New users with no edge: show the builder. Existing users land here only
  // via "My edge" with ?edit=1 — otherwise bounce them to the dashboard.
  if (existing && !isEdit) redirect('/dashboard');
  if (!existing && isEdit) redirect('/edge-builder');

  return <EdgeBuilderClient existingEdgeId={existing?.edgeId} existingConfig={existing?.config} />;
}
