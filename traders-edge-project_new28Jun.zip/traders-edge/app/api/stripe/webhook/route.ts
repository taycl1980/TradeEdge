import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { createAdminClient } from '@/lib/supabase-server';

export const runtime = 'nodejs';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Stripe calls this endpoint when payments succeed or subscriptions
// change. We verify the signature, then update the user's plan in
// Supabase using the admin client (service role).
export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature');

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig!,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook signature failed: ${err.message}` }, { status: 400 });
  }

  const admin = createAdminClient();

  async function setPlan(userId: string, plan: 'pro' | 'free', customerId?: string) {
    const update: Record<string, any> = { plan };
    if (customerId) update.stripe_customer_id = customerId;
    await admin.from('profiles').update(update).eq('id', userId);
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session;
      const userId = session.metadata?.supabase_user_id || session.client_reference_id;
      if (userId) {
        await setPlan(userId, 'pro', session.customer as string);
      }
      break;
    }
    case 'customer.subscription.updated':
    case 'customer.subscription.deleted': {
      const sub = event.data.object as Stripe.Subscription;
      const customerId = sub.customer as string;
      // Find the user by stripe_customer_id and set plan from status.
      const { data: profile } = await admin
        .from('profiles')
        .select('id')
        .eq('stripe_customer_id', customerId)
        .single();
      if (profile) {
        const active = sub.status === 'active' || sub.status === 'trialing';
        await setPlan(profile.id, active ? 'pro' : 'free');
      }
      break;
    }
    default:
      break;
  }

  return NextResponse.json({ received: true });
}
