import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@/lib/supabase-server';

export const runtime = 'nodejs';
export const maxDuration = 60;

const FREE_CAP = parseInt(process.env.FREE_ANALYSIS_CAP || '3', 10);

// The Anthropic client lives ONLY here, on the server. The API key
// is never sent to the browser. This is the core security boundary.
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function POST(req: NextRequest) {
  const supabase = createClient();

  // 1) Require a logged-in user.
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  // 2) Load their plan + usage.
  const { data: profile } = await supabase
    .from('profiles')
    .select('plan, analysis_count')
    .eq('id', user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
  }

  // 3) Enforce the usage cap BEFORE spending money on an API call.
  if (profile.plan !== 'pro' && profile.analysis_count >= FREE_CAP) {
    return NextResponse.json(
      { error: 'cap_reached', cap: FREE_CAP },
      { status: 402 } // Payment Required
    );
  }

  // 4) Validate the payload.
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Bad request' }, { status: 400 });
  }
  const { imageBase64, imageType, prompt } = body;
  if (!imageBase64 || !imageType || !prompt) {
    return NextResponse.json({ error: 'Missing image or prompt' }, { status: 400 });
  }
  if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(imageType)) {
    return NextResponse.json({ error: 'Unsupported image type' }, { status: 400 });
  }

  // 5) Call Claude with the chart + the user's edge.
  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: imageType, data: imageBase64 } },
            { type: 'text', text: prompt },
          ],
        },
      ],
    });

    const text = message.content
      .map((b) => (b.type === 'text' ? b.text : ''))
      .join('')
      .replace(/```json|```/g, '')
      .trim();

    let parsed: any;
    try {
      parsed = JSON.parse(text);
    } catch {
      return NextResponse.json(
        { error: 'Could not parse analysis', raw: text },
        { status: 502 }
      );
    }

    // 6) Only now (success) increment the counter, atomically.
    const { data: newCount } = await supabase.rpc('increment_analysis', { uid: user.id });

    return NextResponse.json({
      analysis: parsed,
      usage: { count: newCount ?? profile.analysis_count + 1, cap: FREE_CAP, plan: profile.plan },
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Analysis failed', detail: err?.message ?? 'unknown' },
      { status: 500 }
    );
  }
}
