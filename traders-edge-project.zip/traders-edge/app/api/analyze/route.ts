import { NextRequest, NextResponse } from 'next/server';
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@/lib/supabase-server';
import { checkRateLimit } from '@/lib/rate-limit';
import { underDailyCap, incrementDailyCap } from '@/lib/spend-cap';

export const runtime = 'nodejs';
export const maxDuration = 60;

const FREE_CAP = parseInt(process.env.FREE_ANALYSIS_CAP || '3', 10);
// Max decoded image size in MB (base64 inflates ~33%, so we check decoded bytes).
const MAX_IMAGE_MB = parseInt(process.env.MAX_IMAGE_MB || '5', 10);

// The Anthropic client lives ONLY here, on the server. The API key
// is never sent to the browser. This is the core security boundary.
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! });

export async function POST(req: NextRequest) {
  const supabase = createClient();

  // 1) Require a logged-in user.
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }

  // 2) RATE LIMIT — per user, and per IP, before any DB or AI work.
  //    Protects against rapid-fire abuse and scripted account misuse.
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const rlUser = await checkRateLimit(`user:${user.id}`);
  const rlIp = await checkRateLimit(`ip:${ip}`);
  if (!rlUser.ok || !rlIp.ok) {
    return NextResponse.json(
      { error: 'rate_limited', message: 'Too many requests — slow down a moment.' },
      { status: 429 }
    );
  }

  // 3) GLOBAL DAILY SPEND CAP — hard backstop on app-wide AI cost.
  if (!(await underDailyCap())) {
    return NextResponse.json(
      { error: 'service_busy', message: 'Analysis is temporarily at capacity. Please try again later.' },
      { status: 503 }
    );
  }

  // 4) Load their plan + usage.
  const { data: profile } = await supabase
    .from('profiles')
    .select('plan, analysis_count')
    .eq('id', user.id)
    .single();

  if (!profile) {
    return NextResponse.json({ error: 'Profile not found' }, { status: 404 });
  }

  // 5) Enforce the per-user free cap BEFORE spending money on an API call.
  if (profile.plan !== 'pro' && profile.analysis_count >= FREE_CAP) {
    return NextResponse.json(
      { error: 'cap_reached', cap: FREE_CAP },
      { status: 402 } // Payment Required
    );
  }

  // 6) Validate the payload.
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Bad request' }, { status: 400 });
  }
  const { imageBase64, imageType, prompt } = body;
  if (!imageBase64 || !imageType || !prompt) {
    return NextResponse.json({ error: 'Missing image or prompt' }, { status: 400 });
  }
  if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(imageType)) {
    return NextResponse.json({ error: 'Unsupported image type' }, { status: 400 });
  }

  // 6b) IMAGE SIZE GUARD — reject oversized images before they reach Anthropic
  //     (controls token cost and blocks payload-bloat abuse). base64 length * 0.75
  //     approximates decoded byte size.
  const approxBytes = Math.floor(imageBase64.length * 0.75);
  if (approxBytes > MAX_IMAGE_MB * 1024 * 1024) {
    return NextResponse.json(
      { error: 'image_too_large', message: `Image exceeds ${MAX_IMAGE_MB}MB. Please upload a smaller screenshot.` },
      { status: 413 }
    );
  }

  // 7) Call Claude with the chart + the user's edge.
  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1200,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: imageType, data: imageBase64 } },
            { type: 'text', text: prompt },
          ],
        },
      ],
    });

    const text = message.content
      .map((b) => (b.type === 'text' ? b.text : ''))
      .join('')
      .replace(/```json|```/g, '')
      .trim();

    let parsed: any;
    try {
      parsed = JSON.parse(text);
    } catch {
      return NextResponse.json(
        { error: 'Could not parse analysis', raw: text },
        { status: 502 }
      );
    }

    // 8) Only now (success) increment both counters.
    const { data: newCount } = await supabase.rpc('increment_analysis', { uid: user.id });
    await incrementDailyCap();

    return NextResponse.json({
      analysis: parsed,
      usage: { count: newCount ?? profile.analysis_count + 1, cap: FREE_CAP, plan: profile.plan },
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: 'Analysis failed', detail: err?.message ?? 'unknown' },
      { status: 500 }
    );
  }
}
