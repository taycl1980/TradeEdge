'use client';

import { useState, useRef, useEffect } from 'react';
import { createClient } from '@/lib/supabase-browser';

// A minimal default edge so a brand-new user can analyze immediately.
const DEFAULT_EDGE = {
  name: 'SMC Starter',
  cf: [
    { label: 'Aligns with HTF trend', pts: 1 },
    { label: 'BOS or CHoCH confirmed', pts: 1 },
    { label: 'FVG / OB / S&D zone at entry', pts: 1 },
    { label: 'Liquidity sweep confirmed', pts: 1 },
    { label: 'No high-impact news within 30 min', pts: 1 },
  ],
  cl: [
    'HTF bias confirmed',
    'Structure break on entry TF',
    'Entry from a marked zone',
    'Stop beyond structure',
    'R:R at least 1:2',
    'No news within 30 min',
  ],
  min: 3,
  full: 5,
  risk: 1,
  rr: 2,
};

type Analysis = {
  read: string;
  factors: { label: string; met: boolean; points: number; note: string }[];
  score: number;
  maxScore: number;
  gate: { rule: string; status: string; note: string }[];
  verdict: 'trade-full' | 'trade-reduced' | 'skip';
  verdictReason: string;
  cautions: string[];
};

export default function DashboardClient({
  userEmail, plan, analysisCount, cap, activeEdge,
}: {
  userEmail: string; plan: string; analysisCount: number; cap: number; activeEdge: any;
}) {
  const supabase = createClient();
  const edge = activeEdge || DEFAULT_EDGE;

  const [img, setImg] = useState<{ data: string; type: string; url: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Analysis | null>(null);
  const [error, setError] = useState('');
  const [showDetail, setShowDetail] = useState(false);
  const [usage, setUsage] = useState({ count: analysisCount, cap, plan });
  const fileRef = useRef<HTMLInputElement>(null);

  // Paste-from-clipboard support (a friction-killer for TradingView users).
  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      const item = Array.from(e.clipboardData?.items || []).find((i) => i.type.startsWith('image/'));
      if (item) {
        const file = item.getAsFile();
        if (file) loadImage(file);
      }
    }
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, []);

  function loadImage(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      setImg({ data: url.split(',')[1], type: file.type, url });
      setResult(null);
      setError('');
      setShowDetail(false);
    };
    reader.readAsDataURL(file);
  }

  function buildPrompt() {
    const factors = edge.cf.map((c: any, i: number) =>
      `${i + 1}. ${c.label} (worth ${c.pts} pt${c.pts > 1 ? 's' : ''})`).join('\n');
    const gate = edge.cl.map((c: any, i: number) =>
      `${i + 1}. ${typeof c === 'string' ? c : c.label}`).join('\n');
    const max = edge.cf.reduce((a: number, c: any) => a + (+c.pts || 0), 0);
    return `You are a disciplined trading analyst evaluating a chart strictly against the trader's OWN edge. Do not substitute your own strategy.

STRATEGY: "${edge.name}"
First, detect the instrument and timeframe from the chart image if visible.

CONFLUENCE MODEL (max ${max} pts; min ${edge.min} to trade, ${edge.full} for full size):
${factors}

ENTRY GATE (all must pass):
${gate}

Assess only what is actually visible. If unclear, do NOT award the point and mark the gate item "unclear". Be conservative and honest.

Respond ONLY with valid JSON, no markdown:
{
  "read": "2-3 sentence read of the chart",
  "factors": [{"label":"","met":true,"points":0,"note":""}],
  "score": 0,
  "maxScore": ${max},
  "gate": [{"rule":"","status":"pass|fail|unclear","note":""}],
  "verdict": "trade-full|trade-reduced|skip",
  "verdictReason": "one sentence",
  "cautions": [""]
}
Thresholds: score>=${edge.full} => "trade-full"; score>=${edge.min} => "trade-reduced"; else "skip".`;
  }

  async function analyze() {
    if (!img) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: img.data, imageType: img.type, prompt: buildPrompt() }),
      });
      if (res.status === 402) { setError('cap'); setLoading(false); return; }
      if (!res.ok) { const e = await res.json(); throw new Error(e.detail || e.error || 'failed'); }
      const json = await res.json();
      setResult(json.analysis);
      if (json.usage) setUsage(json.usage);
    } catch (e: any) {
      setError(e.message || 'Analysis failed');
    } finally {
      setLoading(false);
    }
  }

  async function upgrade(planType: 'monthly' | 'annual') {
    const res = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan: planType }),
    });
    const { url } = await res.json();
    if (url) location.href = url;
  }

  async function signOut() {
    await supabase.auth.signOut();
    location.href = '/login';
  }

  const verdictMap: Record<string, { bg: string; tx: string; label: string; icon: string }> = {
    'trade-full': { bg: 'rgba(29,158,117,.16)', tx: '#5ddca5', label: 'TRADE — Full size', icon: '✓' },
    'trade-reduced': { bg: 'rgba(186,117,23,.16)', tx: '#efc275', label: 'TRADE — Reduced size', icon: '◐' },
    'skip': { bg: 'rgba(216,90,48,.16)', tx: '#f0997b', label: 'SKIP — Below your edge', icon: '✕' },
  };

  return (
    <div style={S.app}>
      <header style={S.header}>
        <div style={S.brand}><div style={S.mark}>◎</div><span style={S.bname}>Trader&apos;s Edge</span></div>
        <div style={S.headerRight}>
          <span style={S.usagePill}>
            {usage.plan === 'pro' ? 'Pro — unlimited' : `${Math.max(0, usage.cap - usage.count)} free analyses left`}
          </span>
          {usage.plan !== 'pro' && (
            <button style={S.upBtn} onClick={() => setError('cap')}>Upgrade</button>
          )}
          <button style={S.signout} onClick={signOut}>Sign out</button>
        </div>
      </header>

      <main style={S.main}>
        <div style={S.edgeBadge}>
          Scoring against <b style={{ color: '#fff' }}>{edge.name}</b> · {edge.cf.length} factors · gate of {edge.cl.length}
        </div>

        <h1 style={S.h1}>Analyze a setup</h1>
        <p style={S.sub}>Drop or paste a candlestick screenshot. The AI reads it against your edge and gives a verdict in one glance.</p>

        {/* Upload zone */}
        {!img && (
          <div
            style={S.drop}
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files[0]) loadImage(e.dataTransfer.files[0]); }}
          >
            <input ref={fileRef} type="file" accept="image/*" hidden
              onChange={(e) => e.target.files?.[0] && loadImage(e.target.files[0])} />
            <div style={{ fontSize: 38, opacity: .4 }}>⬆</div>
            <div style={{ fontWeight: 600, marginTop: 10 }}>Drop, paste (⌘V), or click to upload a chart</div>
            <div style={{ fontSize: 12, color: '#9fb0c9', marginTop: 4 }}>PNG or JPG — a clean candlestick chart works best</div>
          </div>
        )}

        {/* Preview + analyze */}
        {img && (
          <div style={S.card}>
            <img src={img.url} alt="chart" style={S.preview} />
            <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
              <button style={S.primary} onClick={analyze} disabled={loading}>
                {loading ? <span className="spin">◌</span> : '✦'} {loading ? ' Reading your chart…' : ' Analyze against my edge'}
              </button>
              <button style={S.ghost} onClick={() => { setImg(null); setResult(null); }}>Remove</button>
            </div>
          </div>
        )}

        {/* ===== VERDICT IN ONE GLANCE ===== */}
        {result && (
          <>
            <div style={{ ...S.verdictBanner, background: verdictMap[result.verdict].bg }}>
              <div style={{ ...S.verdictIcon, color: verdictMap[result.verdict].tx }}>{verdictMap[result.verdict].icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ ...S.verdictLabel, color: verdictMap[result.verdict].tx }}>{verdictMap[result.verdict].label}</div>
                <div style={S.verdictReason}>{result.verdictReason}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ ...S.bigScore, color: verdictMap[result.verdict].tx }}>{result.score}</div>
                <div style={S.scoreMax}>/ {result.maxScore}</div>
              </div>
            </div>

            <p style={S.readLine}>{result.read}</p>

            <button style={S.detailToggle} onClick={() => setShowDetail(!showDetail)}>
              {showDetail ? 'Hide' : 'Show'} factor-by-factor breakdown {showDetail ? '▲' : '▼'}
            </button>

            {showDetail && (
              <div style={S.card}>
                <div style={S.sectionH}>Confluence factors</div>
                {result.factors.map((f, i) => (
                  <div key={i} style={S.checkRow}>
                    <span style={{ color: f.met ? '#5ddca5' : '#65769180', fontSize: 16 }}>{f.met ? '✓' : '○'}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13.5 }}>{f.label} {f.met && <span style={S.ptBadge}>+{f.points}</span>}</div>
                      {f.note && <div style={S.note}>{f.note}</div>}
                    </div>
                  </div>
                ))}
                <div style={{ ...S.sectionH, marginTop: 18 }}>Entry gate</div>
                {result.gate.map((g, i) => {
                  const c = g.status === 'pass' ? '#5ddca5' : g.status === 'fail' ? '#f0997b' : '#efc275';
                  const ic = g.status === 'pass' ? '✓' : g.status === 'fail' ? '✕' : '?';
                  return (
                    <div key={i} style={S.checkRow}>
                      <span style={{ color: c, fontSize: 16 }}>{ic}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13.5 }}>{g.rule}</div>
                        {g.note && <div style={S.note}>{g.note}</div>}
                      </div>
                    </div>
                  );
                })}
                {result.cautions?.length > 0 && (
                  <div style={S.cautionBox}>
                    {result.cautions.map((c, i) => <div key={i}>⚠ {c}</div>)}
                  </div>
                )}
              </div>
            )}
            <p style={S.disclaimer}>
              An AI read of a static image against your own checklist — decision support, not financial advice or a signal. Verify on your live chart before any entry.
            </p>
          </>
        )}

        {/* Error / cap states */}
        {error === 'cap' && (
          <div style={S.upgradeCard}>
            <h2 style={{ fontSize: 20, marginBottom: 6 }}>Unlock unlimited analysis</h2>
            <p style={{ color: '#9fb0c9', fontSize: 13.5, marginBottom: 18 }}>
              You&apos;ve used your {cap} free chart analyses. Go Pro for unlimited reads, the full performance suite, and edge validation.
            </p>
            <div style={S.priceRow} onClick={() => upgrade('annual')}>
              <div><div style={{ fontWeight: 600 }}>Annual <span style={S.saveBadge}>Save 38%</span></div><div style={S.priceSub}>$7.42/mo billed yearly</div></div>
              <div style={S.price}>$89<span style={S.priceUnit}>/yr</span></div>
            </div>
            <div style={S.priceRowAlt} onClick={() => upgrade('monthly')}>
              <div><div style={{ fontWeight: 600 }}>Monthly</div><div style={S.priceSub}>Cancel anytime</div></div>
              <div style={S.price}>$12<span style={S.priceUnit}>/mo</span></div>
            </div>
            <button style={S.ghostFull} onClick={() => setError('')}>Maybe later</button>
          </div>
        )}
        {error && error !== 'cap' && (
          <div style={S.errorBox}>Could not complete the analysis: {error}</div>
        )}
      </main>
    </div>
  );
}

const S: Record<string, React.CSSProperties> = {
  app: { minHeight: '100vh', background: '#0d1526' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 24px', borderBottom: '1px solid rgba(255,255,255,.09)' },
  brand: { display: 'flex', alignItems: 'center', gap: 10 },
  mark: { width: 34, height: 34, borderRadius: 9, background: 'linear-gradient(135deg,#1d9e75,#0f6e56)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17 },
  bname: { fontWeight: 700, fontSize: 16 },
  headerRight: { display: 'flex', alignItems: 'center', gap: 12 },
  usagePill: { fontSize: 12, color: '#9fb0c9', background: '#1c2942', padding: '5px 11px', borderRadius: 20 },
  upBtn: { background: '#1d9e75', color: '#fff', border: 'none', borderRadius: 8, padding: '7px 14px', fontWeight: 600, fontSize: 13, cursor: 'pointer' },
  signout: { background: 'transparent', color: '#9fb0c9', border: '1px solid rgba(255,255,255,.16)', borderRadius: 8, padding: '6px 12px', fontSize: 13, cursor: 'pointer' },
  main: { maxWidth: 720, margin: '0 auto', padding: '32px 24px 80px' },
  edgeBadge: { background: 'rgba(127,119,221,.16)', border: '1px solid rgba(127,119,221,.25)', color: '#afa9ec', padding: '10px 14px', borderRadius: 9, fontSize: 13, marginBottom: 22 },
  h1: { fontSize: 26, marginBottom: 6 },
  sub: { color: '#9fb0c9', fontSize: 14, marginBottom: 22, lineHeight: 1.6 },
  drop: { border: '1.5px dashed rgba(255,255,255,.16)', borderRadius: 14, padding: '44px 20px', textAlign: 'center', cursor: 'pointer' },
  card: { background: '#15203a', border: '1px solid rgba(255,255,255,.09)', borderRadius: 14, padding: 20, marginBottom: 16 },
  preview: { maxWidth: '100%', borderRadius: 10, border: '1px solid rgba(255,255,255,.09)' },
  primary: { background: '#1d9e75', color: '#fff', border: 'none', borderRadius: 9, padding: '11px 18px', fontWeight: 600, fontSize: 14, cursor: 'pointer' },
  ghost: { background: 'transparent', color: '#eef2f8', border: '1px solid rgba(255,255,255,.16)', borderRadius: 9, padding: '11px 16px', fontSize: 14, cursor: 'pointer' },
  ghostFull: { width: '100%', background: 'transparent', color: '#9fb0c9', border: '1px solid rgba(255,255,255,.16)', borderRadius: 9, padding: '10px', fontSize: 13, cursor: 'pointer', marginTop: 8 },
  verdictBanner: { display: 'flex', alignItems: 'center', gap: 18, padding: '22px 24px', borderRadius: 16, marginTop: 8, marginBottom: 14 },
  verdictIcon: { fontSize: 34, fontWeight: 700 },
  verdictLabel: { fontSize: 20, fontWeight: 700, letterSpacing: '.01em' },
  verdictReason: { fontSize: 13.5, color: '#c8d2e2', marginTop: 3 },
  bigScore: { fontSize: 40, fontWeight: 700, lineHeight: 1 },
  scoreMax: { fontSize: 14, color: '#9fb0c9' },
  readLine: { fontSize: 14, color: '#c8d2e2', lineHeight: 1.6, marginBottom: 14 },
  detailToggle: { background: 'transparent', color: '#85b7eb', border: 'none', fontSize: 13, cursor: 'pointer', padding: '6px 0', marginBottom: 10 },
  sectionH: { fontSize: 11, fontWeight: 600, color: '#9fb0c9', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 10 },
  checkRow: { display: 'flex', gap: 12, padding: '9px 0', borderBottom: '1px solid rgba(255,255,255,.06)' },
  note: { fontSize: 12, color: '#9fb0c9', marginTop: 2 },
  ptBadge: { background: 'rgba(29,158,117,.16)', color: '#5ddca5', fontSize: 10, padding: '2px 6px', borderRadius: 10, marginLeft: 6 },
  cautionBox: { background: 'rgba(186,117,23,.14)', color: '#efc275', padding: 12, borderRadius: 9, fontSize: 12.5, marginTop: 14, lineHeight: 1.7 },
  disclaimer: { fontSize: 11, color: '#65769180', marginTop: 14, lineHeight: 1.6 },
  upgradeCard: { background: '#15203a', border: '1px solid rgba(255,255,255,.16)', borderRadius: 16, padding: 26, marginTop: 16 },
  priceRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', border: '1px solid #1d9e75', background: 'rgba(29,158,117,.14)', borderRadius: 12, padding: '15px 18px', marginBottom: 10, cursor: 'pointer' },
  priceRowAlt: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', border: '1px solid rgba(255,255,255,.09)', borderRadius: 12, padding: '15px 18px', marginBottom: 4, cursor: 'pointer' },
  priceSub: { fontSize: 11.5, color: '#9fb0c9' },
  price: { fontWeight: 700, fontSize: 18 },
  priceUnit: { fontSize: 12, color: '#9fb0c9' },
  saveBadge: { background: 'rgba(29,158,117,.16)', color: '#5ddca5', fontSize: 10, padding: '2px 6px', borderRadius: 10, marginLeft: 6 },
  errorBox: { background: 'rgba(216,90,48,.14)', color: '#f0997b', padding: 14, borderRadius: 9, fontSize: 13, marginTop: 14 },
};
