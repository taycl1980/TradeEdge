import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase-server';
import DashboardClient from './DashboardClient';

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('plan, analysis_count, email')
    .eq('id', user.id)
    .single();

  const { data: edges } = await supabase
    .from('edges')
    .select('*')
    .eq('user_id', user.id)
    .eq('is_active', true)
    .order('updated_at', { ascending: false })
    .limit(1);

  return (
    <DashboardClient
      userEmail={user.email ?? ''}
      plan={profile?.plan ?? 'free'}
      analysisCount={profile?.analysis_count ?? 0}
      cap={parseInt(process.env.FREE_ANALYSIS_CAP || '3', 10)}
      activeEdge={edges?.[0]?.config ?? null}
    />
  );
}
