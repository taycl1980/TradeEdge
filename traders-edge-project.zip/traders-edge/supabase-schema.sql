-- ============================================================
--  Trader's Edge — Database Schema
--  Run this in Supabase → SQL Editor → New query → Run.
--  Sets up tables, Row Level Security, and the usage-cap counter.
-- ============================================================

-- 1) PROFILES ------------------------------------------------
-- One row per user. Mirrors auth.users and holds plan + usage.
-- We deliberately store NOTHING sensitive here: no card data,
-- no API keys. Stripe holds all payment data; we only keep a
-- customer id reference and a plan flag.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free',                 -- 'free' | 'pro'
  stripe_customer_id text,                            -- reference only
  analysis_count integer not null default 0,          -- AI calls used
  created_at timestamptz not null default now()
);

-- 2) EDGES ---------------------------------------------------
-- A user's strategy definition (confluence model, gate, risk).
-- Stored as JSON so the edge builder can evolve without migrations.
create table if not exists public.edges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  config jsonb not null,                              -- factors, gate, risk
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 3) TRADES --------------------------------------------------
create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  data jsonb not null,                                -- full trade record
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
--  ROW LEVEL SECURITY — users can only see/edit their own rows
-- ------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.edges    enable row level security;
alter table public.trades   enable row level security;

create policy "own profile read"   on public.profiles for select using (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "own edges all" on public.edges
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "own trades all" on public.trades
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ------------------------------------------------------------
--  AUTO-CREATE a profile row when a new user signs up
-- ------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ------------------------------------------------------------
--  USAGE CAP: atomically increment analysis_count and return
--  the new value. Called by the /api/analyze route AFTER it
--  confirms the user is allowed. SECURITY DEFINER so it can
--  update the counter under RLS.
-- ------------------------------------------------------------
create or replace function public.increment_analysis(uid uuid)
returns integer
language plpgsql
security definer set search_path = public
as $$
declare
  new_count integer;
begin
  update public.profiles
    set analysis_count = analysis_count + 1
    where id = uid
    returning analysis_count into new_count;
  return new_count;
end;
$$;
